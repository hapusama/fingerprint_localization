#!/usr/bin/env python3
"""Build transferable algorithm inputs from the ExpandedReal-649-v1 baseline."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

import numpy as np


HERE = Path(__file__).resolve().parent
PACKAGE_ROOT = HERE.parents[1]
DATA_UTILS = PACKAGE_ROOT / "data" / "utils"
MODEL_V3 = PACKAGE_ROOT / "model" / "v3"
for module_dir in (DATA_UTILS, MODEL_V3):
    if str(module_dir) not in sys.path:
        sys.path.insert(0, str(module_dir))

import aco_packet_path as aco_base  # noqa: E402
import pgar_heuristic as pgar  # noqa: E402
import usrp_lora_preamble_features as s17  # noqa: E402


DATASET_VERSION = "ExpandedReal-649-v1"
RSSI_FEATURES = list(aco_base.RSSI_PLUS_COLUMNS)
RAW_OFFSETS = list(aco_base.RAW_OFFSETS)
S17_OFFSETS = list(range(-8, 9))
EPS = 1e-12


def read_csv(path: Path) -> tuple[list[str], list[dict]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return list(reader.fieldnames or []), list(reader)


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def packet_key(file_name: str, packet_index: str | int) -> tuple[str, int]:
    return Path(file_name).stem, int(float(packet_index))


def natural_label_key(label: str) -> tuple[int, int]:
    corridor, location = label.split("_", 1)
    return int(corridor), int(location)


def number(row: dict, field: str, default: float = 0.0) -> float:
    try:
        value = float(row.get(field, default))
    except (TypeError, ValueError):
        return default
    return value if math.isfinite(value) else default


def median(values: list[float]) -> float:
    return float(np.median(np.asarray(values, dtype=np.float64)))


def iqr(values: list[float]) -> float:
    array = np.asarray(values, dtype=np.float64)
    return float(np.quantile(array, 0.75) - np.quantile(array, 0.25))


def offset_field(prefix: str, offset: float, digits: int = 2) -> str:
    return f"{prefix}_{offset:+.{digits}f}"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def extract_s17_rows(
    accepted_rows: list[dict],
    iq_dir: Path,
) -> tuple[list[str], list[dict]]:
    by_file: dict[str, list[dict]] = defaultdict(list)
    for row in accepted_rows:
        by_file[row["file_name"]].append(row)
    args = SimpleNamespace(
        skip_preamble_symbols=1,
        feature_symbols=8,
        downsample="mean",
        remove_dc=False,
        peak_width_db=-3.0,
        feature_alignment="per-symbol",
        phase_mode="relative",
        normalize="none",
        power_symbols=8,
    )
    offsets = S17_OFFSETS
    output_rows: list[dict] = []
    for file_name in sorted(by_file):
        path = iq_dir / file_name
        meta = s17.parse_file_meta(path, None, None)
        runtime = s17.build_runtime(meta.sf, 500_000.0, 125_000.0)
        iq = s17.IQMemmap(path)
        for accepted in sorted(by_file[file_name], key=lambda row: int(float(row["packet_index"]))):
            candidate = s17.Candidate(
                sample_start=int(float(accepted["sample_start"])),
                score_db=number(accepted, "detect_score_db"),
                peak_bin_mean=0.0,
                peak_bin_std=number(accepted, "detect_peak_bin_std"),
                peak_width_bins_avg=0.0,
                symbol_scores_db=[],
                symbol_peak_bins=[],
            )
            packet_index = int(float(accepted["packet_index"]))
            feature_row = s17.extract_packet_features(
                iq,
                candidate,
                runtime,
                meta,
                packet_index,
                offsets,
                args,
            )
            feature_row.update(
                {
                    "position_key": accepted["position_key"],
                    "source_key": accepted["source_key"],
                    "recovery_source": accepted["recovery_source"],
                }
            )
            if int(feature_row["feature_symbols"]) != 8:
                raise RuntimeError(f"Incomplete S17 extraction for {accepted['source_key']}")
            output_rows.append(feature_row)
    fields = s17.build_header(offsets, "relative") + ["position_key", "source_key", "recovery_source"]
    return fields, output_rows


def load_spectrum_tensors(
    path: Path,
) -> tuple[
    dict[tuple[str, int], dict[int, dict[float, float]]],
    dict[tuple[str, int], dict[int, dict[float, float]]],
    dict[tuple[str, int], dict[int, dict[float, float]]],
    list[float],
]:
    raw_mag: dict[tuple[str, int], dict[int, dict[float, float]]] = defaultdict(lambda: defaultdict(dict))
    q4_db: dict[tuple[str, int], dict[int, dict[float, float]]] = defaultdict(lambda: defaultdict(dict))
    q4_mag: dict[tuple[str, int], dict[int, dict[float, float]]] = defaultdict(lambda: defaultdict(dict))
    q4_offsets: set[float] = set()
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            key = packet_key(row["file_name"], row["packet_index"])
            symbol_index = int(float(row["local_symbol_index"]))
            q = int(float(row["q"]))
            offset = round(float(row["subbin_offset"]), 6)
            if q == 1 and offset in RAW_OFFSETS:
                raw_mag[key][symbol_index][offset] = float(row["mag_raw"])
            elif q == 4:
                q4_offsets.add(offset)
                q4_db[key][symbol_index][offset] = float(row["mag_db_rel_peak"])
                q4_mag[key][symbol_index][offset] = float(row["mag_raw"])
    return raw_mag, q4_db, q4_mag, sorted(q4_offsets)


def pgar_structure(raw_bins: list[float]) -> list[float]:
    a_m2, a_m1, a0, a_p1, a_p2 = [max(0.0, value) for value in raw_bins]
    total = sum(raw_bins)
    side = a_m2 + a_m1 + a_p1 + a_p2
    left = a_m2 + a_m1
    right = a_p1 + a_p2
    return [
        math.log(a0 + EPS),
        a0 / (total + EPS),
        math.log((side + EPS) / (a0 + EPS)),
        math.log((right + EPS) / (left + EPS)),
        a0 - a_m1,
        a0 - a_p1,
    ]


def build_feature_outputs(
    accepted_rows: list[dict],
    rssi_rows: list[dict],
    s17_rows: list[dict],
    spectrum_path: Path,
    output_dir: Path,
) -> dict:
    accepted_by_key = {
        packet_key(row["file_name"], row["packet_index"]): row for row in accepted_rows
    }
    rssi_by_key = {packet_key(row["file_name"], row["packet_index"]): row for row in rssi_rows}
    s17_by_key = {packet_key(row["file_name"], row["packet_index"]): row for row in s17_rows}
    raw_mag, q4_db, q4_mag, q4_offsets = load_spectrum_tensors(spectrum_path)
    if q4_offsets != [round(-2.0 + 0.25 * index, 6) for index in range(17)]:
        raise RuntimeError(f"Unexpected q4 offsets: {q4_offsets}")

    labels = sorted({row["position_key"] for row in accepted_rows}, key=natural_label_key)
    label_to_id = {label: index for index, label in enumerate(labels)}
    ordered_keys = sorted(
        accepted_by_key,
        key=lambda key: (
            natural_label_key(accepted_by_key[key]["position_key"]),
            key[1],
            key[0],
        ),
    )
    expected_keys = set(ordered_keys)
    for name, keys in {
        "rssi": set(rssi_by_key),
        "s17": set(s17_by_key),
        "raw_spectrum": set(raw_mag),
        "q4_db": set(q4_db),
        "q4_mag": set(q4_mag),
    }.items():
        if keys != expected_keys:
            raise RuntimeError(
                f"{name} key mismatch: missing={len(expected_keys - keys)}, extra={len(keys - expected_keys)}"
            )

    raw_tensor = np.empty((len(ordered_keys), 16, len(RAW_OFFSETS)), dtype=np.float32)
    q4_db_tensor = np.empty((len(ordered_keys), 16, len(q4_offsets)), dtype=np.float32)
    q4_mag_tensor = np.empty_like(q4_db_tensor)
    symbol_rows: list[dict] = []
    packet_rows: list[dict] = []
    ml_rows: list[dict] = []
    pgar_rows: list[dict] = []
    x_rssi: list[list[float]] = []
    x_rssi_s17: list[list[float]] = []
    x_pgar: list[list[float]] = []
    y: list[int] = []
    source_keys: list[str] = []
    position_keys: list[str] = []
    file_stems: list[str] = []
    packet_indices: list[int] = []

    s17_feature_columns = [f"preamble_fft_mag_bin_{offset:+d}" for offset in S17_OFFSETS] + [
        "preamble_peak_to_residual_db",
        "detect_score_db",
        "s17_c_s",
        "s17_j_s",
    ]
    structure_columns = [
        "pgar_log_center",
        "pgar_center_fraction",
        "pgar_log_side_to_center",
        "pgar_log_right_to_left",
        "pgar_center_minus_left1",
        "pgar_center_minus_right1",
    ]

    for sample_index, key in enumerate(ordered_keys):
        accepted = accepted_by_key[key]
        rssi = rssi_by_key[key]
        s17_row = s17_by_key[key]
        label = accepted["position_key"]
        source_key = accepted["source_key"]
        if rssi["position_key"] != label or s17_row["position_key"] != label:
            raise RuntimeError(f"Label mismatch for {source_key}")
        rssi_values = [number(rssi, field) for field in RSSI_FEATURES]
        s17_values = [number(s17_row, field) for field in s17_feature_columns]
        packet_raw_symbols: list[list[float]] = []
        packet_q4_db_symbols: list[list[float]] = []
        packet_q4_mag_symbols: list[list[float]] = []
        for symbol_index in range(16):
            raw_bins = [raw_mag[key][symbol_index][offset] for offset in RAW_OFFSETS]
            q4_db_curve = [q4_db[key][symbol_index][offset] for offset in q4_offsets]
            q4_mag_curve = [q4_mag[key][symbol_index][offset] for offset in q4_offsets]
            zw = aco_base.raw_structure(raw_bins)
            peak_index = max(range(len(q4_mag_curve)), key=lambda index: q4_mag_curve[index])
            side_values = [
                value for value, offset in zip(q4_db_curve, q4_offsets) if abs(offset) >= 1.0
            ]
            symbol_row = {
                "sample_index": sample_index,
                "source_key": source_key,
                "file_stem": key[0],
                "packet_index": key[1],
                "position_key": label,
                "label_id": label_to_id[label],
                "local_symbol_index": symbol_index,
                **{
                    offset_field("raw_mag", offset, 0): value
                    for offset, value in zip(RAW_OFFSETS, raw_bins)
                },
                **{name: value for name, value in zip(aco_base.ZW_COLUMNS, zw)},
                **{
                    offset_field("q4_db", offset): value
                    for offset, value in zip(q4_offsets, q4_db_curve)
                },
                **{
                    offset_field("q4_mag", offset): value
                    for offset, value in zip(q4_offsets, q4_mag_curve)
                },
                "q4_peak_offset": q4_offsets[peak_index],
                "q4_peak_to_side_db": max(q4_db_curve) - sum(side_values) / len(side_values),
            }
            symbol_rows.append(symbol_row)
            packet_raw_symbols.append(raw_bins)
            packet_q4_db_symbols.append(q4_db_curve)
            packet_q4_mag_symbols.append(q4_mag_curve)

        raw_tensor[sample_index] = np.asarray(packet_raw_symbols, dtype=np.float32)
        q4_db_tensor[sample_index] = np.asarray(packet_q4_db_symbols, dtype=np.float32)
        q4_mag_tensor[sample_index] = np.asarray(packet_q4_mag_symbols, dtype=np.float32)
        raw_packet_median = [median([row[index] for row in packet_raw_symbols]) for index in range(5)]
        q4_packet_median = [
            median([row[index] for row in packet_q4_db_symbols]) for index in range(len(q4_offsets))
        ]
        q4_stability = median(
            [
                iqr([row[index] for row in packet_q4_db_symbols])
                for index in range(len(q4_offsets))
            ]
        )
        structure = pgar_structure(raw_packet_median)
        identifiers = {
            "sample_index": sample_index,
            "source_key": source_key,
            "file_stem": key[0],
            "packet_index": key[1],
            "packet_counter": int(float(rssi["packet_counter"])),
            "position_key": label,
            "label_id": label_to_id[label],
            "corridor_id": int(float(rssi["corridor_id"])),
            "location_id": int(float(rssi["location_id"])),
            "distance_m": number(rssi, "distance_m"),
        }
        rssi_block = {field: value for field, value in zip(RSSI_FEATURES, rssi_values)}
        s17_block = {field: value for field, value in zip(s17_feature_columns, s17_values)}
        raw_block = {
            offset_field("raw_packet_median", offset, 0): value
            for offset, value in zip(RAW_OFFSETS, raw_packet_median)
        }
        structure_block = {field: value for field, value in zip(structure_columns, structure)}
        q4_block = {
            "q4_stability": q4_stability,
            **{
                offset_field("q4_packet_median_db", offset): value
                for offset, value in zip(q4_offsets, q4_packet_median)
            },
        }
        qc_block = {
            "sample_start": int(float(accepted["sample_start"])),
            "recovery_source": accepted["recovery_source"],
            "raw_power_db": number(accepted, "raw_power_db"),
            "nonzero_fraction": number(accepted, "nonzero_fraction"),
            "packet_score_db_mean": number(accepted, "packet_score_db_mean"),
            "packet_score_db_std": number(accepted, "packet_score_db_std"),
        }
        packet_rows.append(
            {
                **identifiers,
                **rssi_block,
                **s17_block,
                **raw_block,
                **structure_block,
                **q4_block,
                **qc_block,
            }
        )
        ml_rows.append({**identifiers, **rssi_block, **s17_block})
        pgar_rows.append({**identifiers, **rssi_block, **structure_block, **q4_block})
        x_rssi.append(rssi_values)
        x_rssi_s17.append(rssi_values + s17_values)
        x_pgar.append(rssi_values + structure + [q4_stability] + q4_packet_median)
        y.append(label_to_id[label])
        source_keys.append(source_key)
        position_keys.append(label)
        file_stems.append(key[0])
        packet_indices.append(key[1])

    symbol_fields = list(symbol_rows[0])
    packet_fields = list(packet_rows[0])
    ml_fields = list(ml_rows[0])
    pgar_fields = list(pgar_rows[0])
    write_csv(output_dir / "features" / "symbol_features_10384.csv", symbol_fields, symbol_rows)
    write_csv(output_dir / "features" / "packet_features_649.csv", packet_fields, packet_rows)
    write_csv(output_dir / "features" / "ml_feature_matrix_649.csv", ml_fields, ml_rows)
    write_csv(output_dir / "features" / "pgar_packet_features_649.csv", pgar_fields, pgar_rows)
    label_rows = [
        {
            "label_id": label_to_id[label],
            "position_key": label,
            "corridor_id": natural_label_key(label)[0],
            "location_id": natural_label_key(label)[1],
            "packet_count": sum(value == label for value in position_keys),
        }
        for label in labels
    ]
    write_csv(
        output_dir / "metadata" / "label_mapping.csv",
        ["label_id", "position_key", "corridor_id", "location_id", "packet_count"],
        label_rows,
    )
    (output_dir / "arrays").mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output_dir / "arrays" / "loramorph_expanded649_unscaled.npz",
        X_rssi=np.asarray(x_rssi, dtype=np.float32),
        X_rssi_s17=np.asarray(x_rssi_s17, dtype=np.float32),
        X_pgar=np.asarray(x_pgar, dtype=np.float32),
        raw_symbol_mag=raw_tensor,
        q4_symbol_db=q4_db_tensor,
        q4_symbol_mag=q4_mag_tensor,
        y=np.asarray(y, dtype=np.int64),
        source_key=np.asarray(source_keys),
        position_key=np.asarray(position_keys),
        file_stem=np.asarray(file_stems),
        packet_index=np.asarray(packet_indices, dtype=np.int64),
        rssi_feature_names=np.asarray(RSSI_FEATURES),
        rssi_s17_feature_names=np.asarray(RSSI_FEATURES + s17_feature_columns),
        pgar_feature_names=np.asarray(
            RSSI_FEATURES
            + structure_columns
            + ["q4_stability"]
            + [offset_field("q4_packet_median_db", offset) for offset in q4_offsets]
        ),
        raw_offsets=np.asarray(RAW_OFFSETS, dtype=np.float32),
        q4_offsets=np.asarray(q4_offsets, dtype=np.float32),
    )
    return {
        "ordered_keys": ordered_keys,
        "labels": labels,
        "label_rows": label_rows,
        "q4_offsets": q4_offsets,
        "symbol_rows": len(symbol_rows),
        "packet_rows": len(packet_rows),
        "array_shapes": {
            "X_rssi": [len(ordered_keys), len(RSSI_FEATURES)],
            "X_rssi_s17": [len(ordered_keys), len(RSSI_FEATURES) + len(s17_feature_columns)],
            "X_pgar": [len(ordered_keys), len(RSSI_FEATURES) + len(structure_columns) + 1 + len(q4_offsets)],
            "raw_symbol_mag": list(raw_tensor.shape),
            "q4_symbol_db": list(q4_db_tensor.shape),
            "q4_symbol_mag": list(q4_mag_tensor.shape),
            "y": [len(y)],
        },
        "feature_names": {
            "rssi": RSSI_FEATURES,
            "rssi_s17": RSSI_FEATURES + s17_feature_columns,
            "pgar": RSSI_FEATURES
            + structure_columns
            + ["q4_stability"]
            + [offset_field("q4_packet_median_db", offset) for offset in q4_offsets],
        },
    }


def write_readme(output_dir: Path, summary: dict) -> None:
    text = f"""# LoRaMorph ExpandedReal-649-v1 Algorithm-Ready Dataset

This package contains the pooled, unsplit 32-position real-packet dataset used after 2026-07-16.

## Scope

- Real source packets: {summary['sample_count']}
- Positions: {summary['position_count']}
- Packets per position: {summary['min_packets_per_position']}--{summary['max_packets_per_position']}
- Symbols per packet: 16
- q1 raw offsets: -2, -1, 0, +1, +2
- q4 offsets: -2.00 to +2.00 in 0.25-bin steps
- S17: 17 peak-aligned bins, 8 preamble symbols after skipping symbol 0
- Split status: none; all packets are pooled

## Recommended files

- `inputs/rssi_plus_packet_level_32points_649.csv`: canonical packet-level RSSI input.
- `inputs/lora_frequency_s17_32points_649.csv`: S17 input for RF/MLP and PGAR compatibility.
- `inputs/subbin_spectrum_long_q1q4_32points_649.csv`: canonical ACO v2/v4 long spectrum input.
- `features/ml_feature_matrix_649.csv`: unscaled 27-feature matrix for 1-NN/KNN/RF/XGBoost/MLP.
- `features/pgar_packet_features_649.csv`: packet-level PGAR features.
- `features/symbol_features_10384.csv`: 649 x 16 symbol-level observations.
- `arrays/loramorph_expanded649_unscaled.npz`: aligned matrices and ACO tensors.
- `metadata/label_mapping.csv`: stable label IDs 0--31.
- `DATA_DICTIONARY.xlsx`: human-readable delivery summary and data dictionary.

## Leakage rule

All numeric matrices are intentionally unscaled. After creating a source-packet-safe split, fit scalers,
imputers, feature selectors, augmentation statistics, and prototypes on the training sources only. Do not
fit preprocessing on this pooled full dataset before held-out evaluation.

## Mainline compatibility

ACO v2/v4 can consume the RSSI CSV and q1/q4 spectrum long CSV directly. PGAR can consume the RSSI,
S17, and q1/q4 files. Conventional baselines can use `ml_feature_matrix_649.csv` or the corresponding
arrays in the NPZ file.

## Provenance

The package does not contain the 22.61 GiB raw IQ files. Accepted starts, source manifests, QC exclusions,
recovery reports, extraction parameters, and SHA-256 checksums are included for auditability.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def write_checksums(output_dir: Path) -> list[dict]:
    checksum_path = output_dir / "CHECKSUMS.sha256"
    files = sorted(
        path
        for path in output_dir.rglob("*")
        if path.is_file()
        and path != checksum_path
        and "__pycache__" not in path.parts
    )
    rows = []
    lines = []
    for path in files:
        relative = path.relative_to(output_dir).as_posix()
        digest = sha256(path)
        rows.append({"path": relative, "bytes": path.stat().st_size, "sha256": digest})
        lines.append(f"{digest}  {relative}")
    checksum_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return rows


def run(args: argparse.Namespace) -> dict:
    args.output_dir.mkdir(parents=True, exist_ok=True)
    accepted_fields, accepted_rows = read_csv(args.input_dir / "accepted_packet_starts.csv")
    rssi_fields, rssi_rows = read_csv(args.input_dir / "rssi_plus_packet_level_32points_expanded.csv")
    if len(accepted_rows) != 649 or len(rssi_rows) != 649:
        raise RuntimeError(
            f"Expected 649 accepted/RSSI rows, got {len(accepted_rows)}/{len(rssi_rows)}"
        )

    s17_fields, s17_rows = extract_s17_rows(accepted_rows, args.iq_dir)
    if len(s17_rows) != 649:
        raise RuntimeError(f"Expected 649 S17 rows, got {len(s17_rows)}")

    copy_file(
        args.input_dir / "rssi_plus_packet_level_32points_expanded.csv",
        args.output_dir / "inputs" / "rssi_plus_packet_level_32points_649.csv",
    )
    copy_file(
        args.input_dir / "subbin_spectrum_long_32points_expanded.csv",
        args.output_dir / "inputs" / "subbin_spectrum_long_q1q4_32points_649.csv",
    )
    write_csv(
        args.output_dir / "inputs" / "lora_frequency_s17_32points_649.csv",
        s17_fields,
        s17_rows,
    )

    feature_result = build_feature_outputs(
        accepted_rows,
        rssi_rows,
        s17_rows,
        args.input_dir / "subbin_spectrum_long_32points_expanded.csv",
        args.output_dir,
    )
    for source, name in [
        (args.chirp_template_csv, "chirp_template_measured_16points.csv"),
        (args.chirp_structure_csv, "chirp_structure_measured_16points.csv"),
        (args.location_csv, "location_distance_54points.csv"),
    ]:
        copy_file(source, args.output_dir / "priors" / name)
    for name in [
        "accepted_packet_starts.csv",
        "source_packet_manifest.csv",
        "file_recovery_summary.csv",
        "qc_rejected_packets.csv",
        "legacy_unpaired_packet_starts.csv",
        "EXPANDED_DATASET_REPORT.json",
        "EXPANDED_DATASET_REPORT.md",
    ]:
        copy_file(args.input_dir / name, args.output_dir / "provenance" / name)
    copy_file(Path(__file__), args.output_dir / "scripts" / Path(__file__).name)

    label_counts = Counter(row["position_key"] for row in accepted_rows)
    summary = {
        "dataset_version": DATASET_VERSION,
        "created_date": "2026-07-16",
        "protocol": "source-packet-safe physical 5-second slots; pooled unsplit dataset",
        "sample_count": len(accepted_rows),
        "position_count": len(label_counts),
        "min_packets_per_position": min(label_counts.values()),
        "max_packets_per_position": max(label_counts.values()),
        "symbol_rows": feature_result["symbol_rows"],
        "array_shapes": feature_result["array_shapes"],
        "q4_offsets": feature_result["q4_offsets"],
        "split_status": "none",
        "standardization_status": "unscaled; fit preprocessing on training sources only",
    }
    schema = {
        "dataset_version": DATASET_VERSION,
        "identity_columns": [
            "sample_index",
            "source_key",
            "file_stem",
            "packet_index",
            "position_key",
            "label_id",
        ],
        "rssi_features": RSSI_FEATURES,
        "s17_features": feature_result["feature_names"]["rssi_s17"][len(RSSI_FEATURES) :],
        "ml_27_features": feature_result["feature_names"]["rssi_s17"],
        "pgar_features": feature_result["feature_names"]["pgar"],
        "raw_symbol_offsets": RAW_OFFSETS,
        "q4_symbol_offsets": feature_result["q4_offsets"],
        "scaling_policy": (
            "No scaler is fitted in this package. Fit all preprocessing on training sources only after "
            "a source-packet-safe split."
        ),
    }
    algorithm_map = {
        "1-NN": {"input": "arrays/loramorph_expanded649_unscaled.npz::X_rssi", "shape": [649, 6]},
        "KNN": {"input": "arrays/loramorph_expanded649_unscaled.npz::X_rssi", "shape": [649, 6]},
        "RandomForest": {
            "input": "arrays/loramorph_expanded649_unscaled.npz::X_rssi_s17",
            "shape": [649, 27],
        },
        "XGBoost": {
            "input": "arrays/loramorph_expanded649_unscaled.npz::X_rssi_s17",
            "shape": [649, 27],
        },
        "MLP": {
            "input": "arrays/loramorph_expanded649_unscaled.npz::X_rssi_s17",
            "shape": [649, 27],
        },
        "PGAR": {
            "inputs": [
                "inputs/rssi_plus_packet_level_32points_649.csv",
                "inputs/lora_frequency_s17_32points_649.csv",
                "inputs/subbin_spectrum_long_q1q4_32points_649.csv",
            ]
        },
        "ACO_v2_v4": {
            "inputs": [
                "inputs/rssi_plus_packet_level_32points_649.csv",
                "inputs/subbin_spectrum_long_q1q4_32points_649.csv",
                "priors/chirp_template_measured_16points.csv",
                "priors/chirp_structure_measured_16points.csv",
                "priors/location_distance_54points.csv",
            ],
            "tensor_shapes": {
                "raw_symbol_mag": [649, 16, 5],
                "q4_symbol_db": [649, 16, 17],
            },
        },
    }
    metadata_dir = args.output_dir / "metadata"
    metadata_dir.mkdir(parents=True, exist_ok=True)
    (metadata_dir / "dataset_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (metadata_dir / "feature_schema.json").write_text(
        json.dumps(schema, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (metadata_dir / "algorithm_input_map.json").write_text(
        json.dumps(algorithm_map, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    write_readme(args.output_dir, summary)

    payload = {
        "summary": summary,
        "labels": feature_result["label_rows"],
        "algorithms": algorithm_map,
        "feature_groups": [
            {"group": "RSSI+", "dimensions": 6, "used_by": "1-NN, KNN, RF, XGBoost, MLP, PGAR, ACO"},
            {"group": "S17 packet", "dimensions": 21, "used_by": "RF, XGBoost, MLP, PGAR"},
            {"group": "PGAR packet", "dimensions": 30, "used_by": "PGAR / generic ML"},
            {"group": "q1 symbol tensor", "dimensions": "649x16x5", "used_by": "ACO v2/v4"},
            {"group": "q4 symbol tensor", "dimensions": "649x16x17", "used_by": "PGAR, ACO v2/v4"},
        ],
    }
    (metadata_dir / "workbook_payload.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    file_rows = write_checksums(args.output_dir)
    write_csv(
        metadata_dir / "file_manifest.csv",
        ["path", "bytes", "sha256"],
        file_rows,
    )
    write_checksums(args.output_dir)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument("--iq-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--chirp-template-csv", type=Path, required=True)
    parser.add_argument("--chirp-structure-csv", type=Path, required=True)
    parser.add_argument("--location-csv", type=Path, required=True)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
